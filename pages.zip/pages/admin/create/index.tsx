import { IWork} from "@/@types/work"
import { NextPage } from "next"

export const AdminPage