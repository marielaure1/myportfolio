
import ContactForm from "@/components/contact-component";

export default function Contact() {
    return (
        <>
            <ContactForm />
        </>
    )
}